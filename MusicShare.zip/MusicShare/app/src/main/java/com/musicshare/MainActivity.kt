package com.musicshare

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.media.projection.MediaProjectionManager
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.Gravity
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import java.net.Inet4Address
import java.net.NetworkInterface

class MainActivity : Activity() {

    private lateinit var info: TextView
    private lateinit var btn: Button
    private val handler = Handler(Looper.getMainLooper())

    private val ticker = object : Runnable {
        override fun run() {
            refresh()
            handler.postDelayed(this, 1000)
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_HORIZONTAL
            setPadding(48, 96, 48, 48)
        }
        val title = TextView(this).apply {
            text = "🎵 Music Share"
            textSize = 28f
            gravity = Gravity.CENTER
        }
        btn = Button(this).apply {
            textSize = 18f
            setOnClickListener {
                if (ShareService.running) stopShare() else startShare()
            }
        }
        info = TextView(this).apply {
            textSize = 16f
            setPadding(0, 48, 0, 0)
        }
        root.addView(title)
        root.addView(btn)
        root.addView(info)
        setContentView(root)
    }

    override fun onResume() {
        super.onResume()
        handler.post(ticker)
    }

    override fun onPause() {
        super.onPause()
        handler.removeCallbacks(ticker)
    }

    private fun refresh() {
        if (ShareService.running) {
            btn.text = "⏹ Sharing band karo"
            val urls = ips().joinToString("\n") { "http://$it:8080" }
            info.text = "Sharing CHALU hai ✅\nListeners abhi: ${ShareService.clients}\n\n" +
                "Dusre phones ke browser me ye link kholo:\n$urls\n\n" +
                "Ab koi bhi app (Spotify, YouTube...) bajao, sound sabko jayega."
        } else {
            btn.text = "▶ Sharing shuru karo"
            info.text = (ShareService.error?.let { "Error: $it\n\n" } ?: "") +
                "Steps:\n" +
                "1. Is phone ka hotspot ON karo.\n" +
                "2. Dusre phones ko is hotspot se connect karo.\n" +
                "3. 'Sharing shuru karo' dabao, permissions allow karo.\n" +
                "4. Link dusre phones ke browser me kholo aur 'Suno' dabao."
        }
    }

    private fun startShare() {
        val perms = mutableListOf(Manifest.permission.RECORD_AUDIO)
        if (Build.VERSION.SDK_INT >= 33) perms.add(Manifest.permission.POST_NOTIFICATIONS)
        val need = perms.filter { checkSelfPermission(it) != PackageManager.PERMISSION_GRANTED }
        if (need.isNotEmpty()) {
            requestPermissions(need.toTypedArray(), 1)
        } else {
            launchProjection()
        }
    }

    private fun launchProjection() {
        val mpm = getSystemService(MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
        @Suppress("DEPRECATION")
        startActivityForResult(mpm.createScreenCaptureIntent(), 2)
    }

    @Deprecated("Deprecated in Java")
    override fun onRequestPermissionsResult(
        requestCode: Int, permissions: Array<out String>, grantResults: IntArray
    ) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED) {
            launchProjection()
        } else {
            Toast.makeText(this, "Microphone/Audio permission zaroori hai", Toast.LENGTH_LONG).show()
        }
    }

    @Deprecated("Deprecated in Java")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == 2 && resultCode == RESULT_OK && data != null) {
            val i = Intent(this, ShareService::class.java)
                .putExtra("code", resultCode)
                .putExtra("data", data)
            startForegroundService(i)
        }
    }

    private fun stopShare() {
        stopService(Intent(this, ShareService::class.java))
    }

    private fun ips(): List<String> = try {
        NetworkInterface.getNetworkInterfaces().toList()
            .filter { it.isUp && !it.name.contains("rmnet") && !it.name.contains("ccmni") && !it.name.contains("tun") }
            .flatMap { it.inetAddresses.toList() }
            .filter { !it.isLoopbackAddress && it is Inet4Address }
            .mapNotNull { it.hostAddress }
    } catch (e: Exception) {
        emptyList()
    }
}
