package com.musicshare

import android.content.Context
import java.net.InetSocketAddress
import java.net.ServerSocket
import java.net.Socket
import java.nio.ByteBuffer
import java.security.MessageDigest
import java.util.Base64
import java.util.concurrent.ArrayBlockingQueue
import java.util.concurrent.CopyOnWriteArrayList
import java.util.concurrent.TimeUnit

/**
 * Chhota HTTP + WebSocket server.
 *  GET /    -> listener.html (browser page)
 *  GET /ws  -> WebSocket, binary audio packets
 * Packet = 8 bytes (big-endian double, host time in ms) + PCM16 stereo 44100 Hz
 */
class StreamServer(private val context: Context, private val port: Int = 8080) {

    private class Client(val socket: Socket) {
        val queue = ArrayBlockingQueue<ByteArray>(60)
    }

    private var server: ServerSocket? = null
    @Volatile private var running = false
    private val clients = CopyOnWriteArrayList<Client>()

    val clientCount: Int get() = clients.size

    fun start() {
        running = true
        val s = ServerSocket()
        s.reuseAddress = true
        s.bind(InetSocketAddress(port))
        server = s
        Thread {
            while (running) {
                try {
                    val sock = s.accept()
                    Thread { handle(sock) }.start()
                } catch (e: Exception) {
                    if (!running) break
                }
            }
        }.start()
    }

    fun stop() {
        running = false
        try { server?.close() } catch (_: Exception) {}
        for (c in clients) {
            try { c.socket.close() } catch (_: Exception) {}
        }
        clients.clear()
    }

    fun broadcast(pcm: ByteArray, len: Int) {
        if (clients.isEmpty()) return
        val bb = ByteBuffer.allocate(8 + len)
        bb.putDouble(System.currentTimeMillis().toDouble())
        bb.put(pcm, 0, len)
        val packet = bb.array()
        for (c in clients) {
            if (!c.queue.offer(packet)) {
                // listener slow hai, purana data hata do
                c.queue.clear()
                c.queue.offer(packet)
            }
        }
    }

    private fun handle(sock: Socket) {
        try {
            sock.tcpNoDelay = true
            val reader = sock.getInputStream().bufferedReader(Charsets.ISO_8859_1)
            val requestLine = reader.readLine() ?: run { sock.close(); return }
            val headers = HashMap<String, String>()
            while (true) {
                val line = reader.readLine() ?: break
                if (line.isEmpty()) break
                val i = line.indexOf(':')
                if (i > 0) headers[line.substring(0, i).trim().lowercase()] = line.substring(i + 1).trim()
            }
            val path = requestLine.split(" ").getOrNull(1) ?: "/"
            val out = sock.getOutputStream()

            val key = headers["sec-websocket-key"]
            if (headers["upgrade"]?.lowercase() == "websocket" && key != null) {
                val accept = Base64.getEncoder().encodeToString(
                    MessageDigest.getInstance("SHA-1")
                        .digest((key + "258EAFA5-E914-47DA-95CA-C5AB0DC85B11").toByteArray())
                )
                out.write(
                    ("HTTP/1.1 101 Switching Protocols\r\n" +
                        "Upgrade: websocket\r\n" +
                        "Connection: Upgrade\r\n" +
                        "Sec-WebSocket-Accept: $accept\r\n\r\n").toByteArray()
                )
                out.flush()
                val client = Client(sock)
                clients.add(client)
                try {
                    while (running && !sock.isClosed) {
                        val pkt = client.queue.poll(1, TimeUnit.SECONDS) ?: continue
                        out.write(frame(pkt))
                        out.flush()
                    }
                } catch (_: Exception) {
                } finally {
                    clients.remove(client)
                    try { sock.close() } catch (_: Exception) {}
                }
            } else {
                val html = context.assets.open("listener.html").readBytes()
                out.write(
                    ("HTTP/1.1 200 OK\r\n" +
                        "Content-Type: text/html; charset=utf-8\r\n" +
                        "Content-Length: ${html.size}\r\n" +
                        "Cache-Control: no-store\r\n" +
                        "Connection: close\r\n\r\n").toByteArray()
                )
                out.write(html)
                out.flush()
                sock.close()
            }
        } catch (_: Exception) {
            try { sock.close() } catch (_: Exception) {}
        }
    }

    private fun frame(payload: ByteArray): ByteArray {
        val n = payload.size
        val header: ByteArray = if (n < 126) {
            byteArrayOf(0x82.toByte(), n.toByte())
        } else {
            byteArrayOf(0x82.toByte(), 126, (n shr 8).toByte(), (n and 0xFF).toByte())
        }
        val out = ByteArray(header.size + n)
        System.arraycopy(header, 0, out, 0, header.size)
        System.arraycopy(payload, 0, out, header.size, n)
        return out
    }
}
