package com.musicshare

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Intent
import android.content.pm.ServiceInfo
import android.media.AudioAttributes
import android.media.AudioFormat
import android.media.AudioPlaybackCaptureConfiguration
import android.media.AudioRecord
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.os.IBinder
import kotlin.math.max

class ShareService : Service() {

    companion object {
        const val ACTION_STOP = "com.musicshare.STOP"
        @Volatile var running = false
        @Volatile var clients = 0
        @Volatile var error: String? = null
    }

    private var projection: MediaProjection? = null
    private var record: AudioRecord? = null
    private var server: StreamServer? = null
    @Volatile private var capturing = false

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent == null || intent.action == ACTION_STOP) {
            stopSelf()
            return START_NOT_STICKY
        }
        if (running) return START_NOT_STICKY

        startAsForeground()

        try {
            val code = intent.getIntExtra("code", 0)
            @Suppress("DEPRECATION")
            val data = intent.getParcelableExtra<Intent>("data")
            val mpm = getSystemService(MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
            val proj = mpm.getMediaProjection(code, data!!)
            proj.registerCallback(object : MediaProjection.Callback() {
                override fun onStop() {
                    stopSelf()
                }
            }, null)
            projection = proj

            val config = AudioPlaybackCaptureConfiguration.Builder(proj)
                .addMatchingUsage(AudioAttributes.USAGE_MEDIA)
                .addMatchingUsage(AudioAttributes.USAGE_GAME)
                .addMatchingUsage(AudioAttributes.USAGE_UNKNOWN)
                .build()

            val format = AudioFormat.Builder()
                .setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                .setSampleRate(44100)
                .setChannelMask(AudioFormat.CHANNEL_IN_STEREO)
                .build()

            val minBuf = AudioRecord.getMinBufferSize(
                44100, AudioFormat.CHANNEL_IN_STEREO, AudioFormat.ENCODING_PCM_16BIT
            )

            @Suppress("MissingPermission")
            val rec = AudioRecord.Builder()
                .setAudioFormat(format)
                .setBufferSizeInBytes(max(minBuf, 16384))
                .setAudioPlaybackCaptureConfig(config)
                .build()
            record = rec

            val srv = StreamServer(this, 8080)
            srv.start()
            server = srv

            error = null
            running = true
            capturing = true
            rec.startRecording()

            Thread {
                val buf = ByteArray(4096)
                while (capturing) {
                    val n = rec.read(buf, 0, buf.size)
                    if (n > 0) {
                        srv.broadcast(buf, n)
                        clients = srv.clientCount
                    } else if (n < 0) {
                        break
                    }
                }
            }.start()
        } catch (e: Exception) {
            error = e.toString()
            stopSelf()
        }
        return START_NOT_STICKY
    }

    private fun startAsForeground() {
        val nm = getSystemService(NOTIFICATION_SERVICE) as NotificationManager
        nm.createNotificationChannel(
            NotificationChannel("share", "Music Share", NotificationManager.IMPORTANCE_LOW)
        )
        val n = Notification.Builder(this, "share")
            .setContentTitle("Music Share chal raha hai")
            .setContentText("Sound dusre phones ko bheja ja raha hai")
            .setSmallIcon(android.R.drawable.ic_media_play)
            .build()
        startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION)
    }

    override fun onDestroy() {
        capturing = false
        running = false
        clients = 0
        try { record?.stop() } catch (_: Exception) {}
        try { record?.release() } catch (_: Exception) {}
        try { server?.stop() } catch (_: Exception) {}
        try { projection?.stop() } catch (_: Exception) {}
        super.onDestroy()
    }
}
